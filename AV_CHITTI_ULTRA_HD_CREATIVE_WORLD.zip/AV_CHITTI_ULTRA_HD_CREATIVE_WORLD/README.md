# AV Creative World Ultra HD — CHITTI Edition

## Included
- CHITTI AI 3D Designer
- High-resolution WebGL rendering (device dependent)
- ACES tone mapping
- Soft shadows
- Procedural terrain
- Water
- City and roads
- Dense environment
- Laboratory and robotic arm
- Day/night cycle
- Weather states
- Creative Mode
- First/experimental third-person camera
- Fly mode
- GLB/GLTF import
- CHITTI structured prompt generation

## Controls
WASD move
Mouse look
F fly
V camera
Left click place
Right click remove
1-6 select
U import GLB/GLTF

For true AAA-level visuals, add licensed/original high-quality PBR models and textures to assets/.
Keep private AI API keys on a backend, never inside this frontend.
